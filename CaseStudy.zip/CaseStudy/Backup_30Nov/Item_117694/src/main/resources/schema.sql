DROP TABLE IF EXISTS item_117694;

CREATE TABLE item_117694
(
    id varchar(36) NOT NULL,
    name varchar(500) DEFAULT NULL,
    description varchar(500) DEFAULT NULL,
    price double DEFAULT NULL   
);
