DROP TABLE IF EXISTS customer_117694;

CREATE TABLE customer_117694
(
    id varchar(36) NOT NULL,
    email varchar(200) DEFAULT NULL,
    first_name varchar(500) DEFAULT NULL,
    last_name varchar(500) DEFAULT NULL   
);
