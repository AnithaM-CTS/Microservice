insert into customer_117694(id,email,first_name,last_name) values('1','p@gmail.com','Poo','Ven');
insert into customer_117694(id,email,first_name,last_name) values('2','m@gmail.com','Mon','Ra');


