insert into item_117694(id,name,description,price) values('1','table','TABLE DESC','10000.56');
insert into item_117694(id,name,description,price) values('2','fan','FAN DESC','1627.76');


