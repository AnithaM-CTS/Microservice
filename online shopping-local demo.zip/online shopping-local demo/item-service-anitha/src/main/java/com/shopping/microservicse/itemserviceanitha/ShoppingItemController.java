package com.shopping.microservicse.itemserviceanitha;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShoppingItemController {
    
	@Autowired
    ShoppingItemRepository shoppingItemRepository;
    
	private static final Logger logger = LoggerFactory.getLogger(ShoppingItemController.class);
	
	@GetMapping("/items")
	public List<ShoppingItem> getItemDetails() {
		logger.info("inside item service - get all items");
		List<ShoppingItem> item = shoppingItemRepository.findAll();
		return item;
		}
	@GetMapping("/item/{itemName}")
	public ShoppingItem getItemByItemName(@PathVariable String itemName) {
		logger.info("inside item service - get item by item name");
	    ShoppingItem  item1 = shoppingItemRepository.findByItemName(itemName);
	    return item1;
		//return new  ShoppingItem(111L,"thermometer","health supplies",200.00);
	}
}
