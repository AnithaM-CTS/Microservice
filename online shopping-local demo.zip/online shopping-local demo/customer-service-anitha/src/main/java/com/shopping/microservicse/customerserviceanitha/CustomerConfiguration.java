package com.shopping.microservicse.customerserviceanitha;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix="customer-service-anitha")
@Component
public class CustomerConfiguration {
     private String defaultFirstName;
     private String defaultLastName;
     private Long defaultId;
     private String defaultEmailId;
	public String getDefaultFirstName() {
		return defaultFirstName;
	}
	public void setDefaultFirstName(String defaultFirstName) {
		this.defaultFirstName = defaultFirstName;
	}
	public String getDefaultLastName() {
		return defaultLastName;
	}
	public void setDefaultLastName(String defaultLastName) {
		this.defaultLastName = defaultLastName;
	}
	public Long getDefaultId() {
		return defaultId;
	}
	public void setDefaultId(Long defaultId) {
		this.defaultId = defaultId;
	}
	public String getDefaultEmailId() {
		return defaultEmailId;
	}
	public void setDefaultEmailId(String defaultEmailId) {
		this.defaultEmailId = defaultEmailId;
	}
     
}
