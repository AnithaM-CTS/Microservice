package com.configserver.demo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
