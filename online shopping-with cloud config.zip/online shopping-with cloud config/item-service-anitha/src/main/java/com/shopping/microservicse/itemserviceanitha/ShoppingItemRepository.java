package com.shopping.microservicse.itemserviceanitha;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShoppingItemRepository extends JpaRepository<ShoppingItem, Long> {

	public ShoppingItem findByItemName(String itemName);

}
