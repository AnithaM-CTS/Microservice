package com.shopping.microservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IpmCustomerServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
