insert into employee(emp_id,first_name,last_name,date_of_joining) values (176917,'Anitha','Murugesan',sysdate());
insert into employee(emp_id,first_name,last_name,date_of_joining) values (282547,'Swetha','Reddy',sysdate());
insert into employee(emp_id,first_name,last_name,date_of_joining) values (404360,'Govind','S',sysdate());