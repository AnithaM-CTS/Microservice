package com.payroll.microservices.employeeservice;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeServiceApplicationTests {

	
	void contextLoads() {
	}

}
