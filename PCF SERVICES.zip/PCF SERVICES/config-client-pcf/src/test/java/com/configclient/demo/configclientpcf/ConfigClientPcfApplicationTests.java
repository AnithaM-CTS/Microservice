package com.configclient.demo.configclientpcf;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigClientPcfApplicationTests {

	@Test
	void contextLoads() {
	}

}
