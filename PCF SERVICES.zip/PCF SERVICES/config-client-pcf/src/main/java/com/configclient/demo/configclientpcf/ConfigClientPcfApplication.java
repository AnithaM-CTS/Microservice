package com.configclient.demo.configclientpcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClientPcfApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigClientPcfApplication.class, args);
	}

}
