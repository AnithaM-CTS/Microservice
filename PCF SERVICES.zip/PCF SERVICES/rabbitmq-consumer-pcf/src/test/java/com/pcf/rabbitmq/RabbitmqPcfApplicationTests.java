package com.pcf.rabbitmq;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqPcfApplicationTests {

	@Test
	void contextLoads() {
	}

}
