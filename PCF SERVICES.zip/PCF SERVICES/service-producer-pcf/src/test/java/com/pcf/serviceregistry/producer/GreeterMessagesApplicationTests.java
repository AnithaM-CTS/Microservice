package com.pcf.serviceregistry.producer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreeterMessagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
