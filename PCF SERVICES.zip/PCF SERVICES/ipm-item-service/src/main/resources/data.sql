insert into item(item_id,item_name,item_description,item_price) values(100,'chicken','chilli chicken',250.0);
insert into item(item_id,item_name,item_description,item_price) values(101,'rice','Rice from indian brand',150.0);
insert into item(item_id,item_name,item_description,item_price) values(102,'mutton','mutton do pyaja',350.0);