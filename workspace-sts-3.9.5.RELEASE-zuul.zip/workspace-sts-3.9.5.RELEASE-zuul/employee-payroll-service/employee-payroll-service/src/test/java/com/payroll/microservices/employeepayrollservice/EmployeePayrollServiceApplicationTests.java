package com.payroll.microservices.employeepayrollservice;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePayrollServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
