insert into employee_role(role_id,role_name,description) values (10001, 'HR','Human Resource');
insert into employee_role(role_id,role_name,description) values (10002, 'TL','Technical Lead');
insert into employee_role(role_id,role_name,description) values (10003, 'TA','Technical Architect');