package com.payroll.microservices.rollservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeRollController {
	@Autowired
	EmployeeRoleRepository employeeRoleRepository; 
	@GetMapping("/role/{roleName}")
	public EmployeeRole getRoleMappingByName(@PathVariable String roleName) {
	//return new EmployeeRole(176917L,"TL","Technical Lead");
		EmployeeRole employeeRole = employeeRoleRepository.findByRoleName(roleName);
		return employeeRole;
	}
}
