insert into employee(emp_id,first_name,last_name,date_of_joining,port) values (176917,'Anitha','Murugesan',sysdate(),0);
insert into employee(emp_id,first_name,last_name,date_of_joining,port) values (282547,'Swetha','Reddy',sysdate(),0);
insert into employee(emp_id,first_name,last_name,date_of_joining,port) values (404360,'Govind','S',sysdate(),0);