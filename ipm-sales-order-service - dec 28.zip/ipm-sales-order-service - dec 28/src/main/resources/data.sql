insert into SALES_ORDER(id,order_date,cust_id,order_desc,total_price) values(99,sysdate(),'12','chilli chicken',250.0);
