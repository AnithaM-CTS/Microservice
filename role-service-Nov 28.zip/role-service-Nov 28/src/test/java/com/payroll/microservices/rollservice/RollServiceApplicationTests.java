package com.payroll.microservices.rollservice;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RollServiceApplicationTests {

	//@Test
	void contextLoads() {
	}

}
